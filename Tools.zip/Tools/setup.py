from setuptools import setup, find_packages

setup(
    name='cairo-transport',
    version='0.1',
    packages=find_packages(),
    install_requires=[
        'streamlit',
        'networkx',
        'folium',
        'plotly',
        'pandas'
    ],
    entry_points={
        'console_scripts': [
            'cairo-transport = app:main'
        ]
    },
)
