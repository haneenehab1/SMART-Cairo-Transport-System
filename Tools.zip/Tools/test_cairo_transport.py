import unittest
from cairo_transport import build_transport_graph

class TestCairoTransport(unittest.TestCase):
    def test_graph_not_empty(self):
        G = build_transport_graph()
        self.assertGreater(len(G.nodes), 0)
        self.assertGreater(len(G.edges), 0)

if __name__ == '__main__':
    unittest.main()
