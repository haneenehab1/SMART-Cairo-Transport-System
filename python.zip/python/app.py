import streamlit as st
import folium
from folium.plugins import HeatMap
import networkx as nx
import plotly.express as px
import plotly.graph_objects as go
from streamlit_folium import folium_static
import pandas as pd
from cairo_transport import CairoTransportSystem
from datetime import datetime
import os
import json
import time

# Set page configuration
st.set_page_config(
    page_title="Cairo Transport System",
    page_icon="🚌",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize session state
if 'transport_system' not in st.session_state:
    st.session_state.transport_system = CairoTransportSystem()
if 'current_path' not in st.session_state:
    st.session_state.current_path = None
if 'current_mst' not in st.session_state:
    st.session_state.current_mst = None
if 'wait_times' not in st.session_state:
    st.session_state.wait_times = {}
if 'emergency_mode' not in st.session_state:
    st.session_state.emergency_mode = False
if 'show_mst' not in st.session_state:
    st.session_state.show_mst = False

# Main title
st.title("Cairo Transport System 🇪🇬")

# Sidebar
with st.sidebar:
    st.header("Navigation")
    
    tab_selection = st.radio(
        "Choose a feature:",
        ["Route Finder", "Network Analysis", "Traffic Analysis", "Bus Schedule", "Emergency Services"]
    )
    
    st.divider()
    
    # Common controls
    st.subheader("Location Selection")
    
    # Get all nodes in the graph
    all_locations = sorted(list(st.session_state.transport_system.G.nodes()))
    
    start_location = st.selectbox(
        "Starting Point:",
        all_locations,
        index=0 if all_locations else None,
        key="start_location"
    )
    
    end_location = st.selectbox(
        "Destination:",
        all_locations,
        index=min(1, len(all_locations) - 1) if len(all_locations) > 1 else None,
        key="end_location"
    )
    
    # Special controls for Emergency mode
    if tab_selection == "Emergency Services":
        st.divider()
        st.subheader("Emergency Settings")
        emergency_toggle = st.toggle(
            "Emergency Vehicle Mode", 
            value=st.session_state.emergency_mode,
            key="emergency_toggle"
        )
        st.session_state.emergency_mode = emergency_toggle
        st.session_state.transport_system.emergency_mode = emergency_toggle
        
        if emergency_toggle:
            hospitals = list(st.session_state.transport_system.hospitals.keys())
            to_hospital = st.selectbox("Select Hospital", hospitals)
            
            if st.button("Find Fastest Route to Hospital", type="primary"):
                try:
                    if st.session_state.emergency_mode:
                        path, length = st.session_state.transport_system.a_star_shortest_path(start_location, to_hospital)
                    else:
                        path, length = st.session_state.transport_system.dijkstra_shortest_path(start_location, to_hospital)
                    
                    # Calculate wait times
                    wait_times = st.session_state.transport_system.calculate_traffic_wait_times(path, datetime.now())
                    
                    # Optimize for emergency
                    if st.session_state.emergency_mode:
                        path, wait_times = st.session_state.transport_system.optimize_emergency_route(path, wait_times)
                    
                    st.session_state.current_path = path
                    st.session_state.wait_times = wait_times
                    st.toast(f"📍 Found route with length: {length:.2f} km")
                except Exception as e:
                    st.error(f"Error finding path: {str(e)}")


# Main content area
if tab_selection == "Route Finder":
    st.header("Route Finder")
    
    col1, col2 = st.columns([3, 1])
    
    with col2:
        st.subheader("Route Options")
        
        path_algorithm = st.radio(
            "Path Algorithm:",
            ["Dijkstra", "A*", "Time-Dependent"],
            key="path_algorithm"
        )
        
        current_time = datetime.now()
        if path_algorithm == "Time-Dependent":
            st.write("Set departure time:")
            hour = st.slider("Hour:", 0, 23, current_time.hour)
            minute = st.slider("Minute:", 0, 59, current_time.minute)
            current_time = current_time.replace(hour=hour, minute=minute)
            st.write(f"Selected time: {current_time.strftime('%H:%M')}")
        
        if st.button("Find Route", type="primary"):
            if not start_location or not end_location:
                st.error("Please select both start and destination locations.")
            elif start_location == end_location:
                st.error("Start and destination locations must be different.")
            else:
                with st.spinner("Finding optimal route..."):
                    try:
                        if path_algorithm == "Dijkstra":
                            path, length = st.session_state.transport_system.dijkstra_shortest_path(start_location, end_location)
                        elif path_algorithm == "A*":
                            path, length = st.session_state.transport_system.a_star_shortest_path(start_location, end_location)
                        else:  # Time-Dependent
                            path, length = st.session_state.transport_system.time_dependent_shortest_path(start_location, end_location, current_time)
                        
                        # Calculate wait times
                        wait_times = st.session_state.transport_system.calculate_traffic_wait_times(path, current_time)
                        
                        st.session_state.current_path = path
                        st.session_state.wait_times = wait_times
                        st.toast(f"📍 Found route with length: {length:.2f} km")
                    except Exception as e:
                        st.error(f"Error finding path: {str(e)}")
    
    with col1:
        st.subheader("Map View")
        
        if st.session_state.current_path:
            # Create map
            transport_map = st.session_state.transport_system.create_folium_map()
            
            # Add path to map
            transport_map = st.session_state.transport_system.visualize_path_on_map(
                transport_map, 
                st.session_state.current_path,
                color='blue'
            )
            
            # Display the map
            folium_static(transport_map, width=700, height=500)
            
            # Route details
            st.subheader("Route Details")
            
            # Distance and time calculation
            route_length = 0
            for i in range(len(st.session_state.current_path)-1):
                u = st.session_state.current_path[i]
                v = st.session_state.current_path[i+1]
                if st.session_state.transport_system.G.has_edge(u, v):
                    route_length += st.session_state.transport_system.G[u][v]['weight']
            
            avg_speed = 40  # km/h
            estimated_time = route_length / avg_speed * 60  # minutes
            
            wait_time = sum(st.session_state.wait_times.values()) / 60  # minutes
            
            st.write(f"**Total distance:** {route_length:.2f} km")
            st.write(f"**Estimated travel time:** {estimated_time:.1f} minutes")
            st.write(f"**Traffic light wait time:** {wait_time:.1f} minutes")
            st.write(f"**Total time:** {estimated_time + wait_time:.1f} minutes")
            
            # Show route steps
            st.subheader("Route Steps")
            for i in range(len(st.session_state.current_path)):
                location = st.session_state.current_path[i]
                if i == 0:
                    st.write(f"1. Start at **{location}**")
                elif i == len(st.session_state.current_path) - 1:
                    st.write(f"{i+1}. Arrive at **{location}**")
                else:
                    # Calculate distance from previous
                    prev = st.session_state.current_path[i-1]
                    if st.session_state.transport_system.G.has_edge(prev, location):
                        distance = st.session_state.transport_system.G[prev][location]['distance']
                        st.write(f"{i+1}. Continue to **{location}** ({distance:.2f} km)")
                        
                        # Show wait time if there's a traffic signal
                        if location in st.session_state.wait_times:
                            wait = st.session_state.wait_times[location]
                            if wait > 0:
                                st.write(f"   ⏱️ Traffic signal wait: {wait:.1f} seconds")
        else:
            # Create default map
            transport_map = st.session_state.transport_system.create_folium_map()
            folium_static(transport_map, width=700, height=500)
            st.info("Select start and destination locations, then click 'Find Route'")

elif tab_selection == "Network Analysis":
    st.header("Network Analysis")
    
    col1, col2 = st.columns([3, 1])
    
    with col2:
        st.subheader("Analysis Options")
        
        show_mst = st.toggle("Show Minimum Spanning Tree", value=st.session_state.show_mst)
        st.session_state.show_mst = show_mst
        
        if show_mst and st.button("Calculate MST", type="primary"):
            with st.spinner("Calculating Minimum Spanning Tree..."):
                try:
                    mst = st.session_state.transport_system.kruskal_mst()
                    st.session_state.current_mst = mst
                    
                    # Calculate total MST weight
                    total_weight = sum(mst[u][v]['weight'] for u, v in mst.edges())
                    st.success(f"MST calculated successfully. Total weight: {total_weight:.2f}")
                except Exception as e:
                    st.error(f"Error calculating MST: {str(e)}")
        
        st.divider()
        
        st.subheader("Network Statistics")
        
        # Calculate some basic network metrics
        G = st.session_state.transport_system.G
        num_nodes = len(G.nodes())
        num_edges = len(G.edges())
        avg_degree = sum(dict(G.degree()).values()) / num_nodes
        density = 2 * num_edges / (num_nodes * (num_nodes - 1))
        
        st.write(f"**Number of locations:** {num_nodes}")
        st.write(f"**Number of roads:** {num_edges}")
        st.write(f"**Average connections:** {avg_degree:.2f}")
        st.write(f"**Network density:** {density:.4f}")
        
        # Try to calculate connectivity metrics
        try:
            is_connected = nx.is_connected(G)
            n_components = nx.number_connected_components(G)
            st.write(f"**Network connected:** {'Yes' if is_connected else 'No'}")
            if not is_connected:
                st.write(f"**Number of components:** {n_components}")
        except:
            st.write("**Network connectivity:** Calculation not available")
    
    with col1:
        st.subheader("Network Visualization")
        
        # Create map
        network_map = st.session_state.transport_system.create_folium_map()
        
        # Add MST if calculated and enabled
        if st.session_state.show_mst and st.session_state.current_mst:
            network_map = st.session_state.transport_system.visualize_mst_on_map(
                network_map, 
                st.session_state.current_mst,
                color='red'
            )
        
        # Display the map
        folium_static(network_map, width=700, height=500)
        
        if st.session_state.show_mst and st.session_state.current_mst:
            st.info("The Minimum Spanning Tree (MST) shows the most efficient way to connect all locations with the minimum total distance.")
            
            # MST Details
            st.subheader("MST Details")
            
            mst = st.session_state.current_mst
            mst_edges = list(mst.edges(data=True))
            
            # Create DataFrame for MST edges
            mst_data = []
            for u, v, data in mst_edges:
                mst_data.append({
                    "From": u,
                    "To": v,
                    "Distance (km)": data.get('distance', 0),
                    "Traffic Factor": data.get('traffic', 1.0),
                    "Weight": data.get('weight', 0)
                })
            
            mst_df = pd.DataFrame(mst_data)
            st.dataframe(mst_df, hide_index=True)

elif tab_selection == "Traffic Analysis":
    st.header("Traffic Analysis")
    
    # Row for time analysis
    if start_location and end_location and start_location != end_location:
        st.subheader("Travel Time Analysis by Time of Day")
        
        try:
            labels, times = st.session_state.transport_system.get_time_analysis_data(start_location, end_location)
            
            if labels and times:
                # Create a bar chart using Plotly
                fig = px.bar(
                    x=labels, 
                    y=times,
                    labels={'x': 'Time of Day', 'y': 'Travel Time (minutes)'},
                    title=f"Travel Time: {start_location} to {end_location}",
                    color=times,
                    color_continuous_scale="Viridis"
                )
                
                fig.update_layout(
                    xaxis_tickangle=-45,
                    yaxis_title="Travel Time (minutes)",
                    height=500
                )
                
                st.plotly_chart(fig, use_container_width=True)
                
                # Analysis text
                max_time = max(times)
                min_time = min(times)
                max_idx = times.index(max_time)
                min_idx = times.index(min_time)
                
                st.info(f"Best time to travel: **{labels[min_idx]}** (Travel time: {min_time:.2f} minutes)")
                st.warning(f"Worst time to travel: **{labels[max_idx]}** (Travel time: {max_time:.2f} minutes)")
                st.write(f"Difference between best and worst: **{max_time - min_time:.2f} minutes** ({((max_time/min_time)-1)*100:.1f}% increase)")
            else:
                st.error("Could not calculate time analysis for the selected locations.")
        except Exception as e:
            st.error(f"Error in time analysis: {str(e)}")
    else:
        st.info("Please select different start and destination locations for time analysis.")
    
    # Traffic signals analysis
    st.divider()
    st.subheader("Traffic Signal Analysis")
    
    # Create a DataFrame for traffic signals
    signals_data = []
    for node, signal in st.session_state.transport_system.traffic_signals.items():
        signals_data.append({
            "Intersection": node,
            "Cycle Time (sec)": signal['cycle_time'],
            "Green Time (sec)": signal['green_time'],
            "Red Time (sec)": signal['red_time'],
        })
    
    signals_df = pd.DataFrame(signals_data)
    
    # Create two columns
    col1, col2 = st.columns([3, 2])
    
    with col1:
        # Traffic signal data table
        st.write("Traffic Signal Timings")
        st.dataframe(signals_df, hide_index=True, use_container_width=True)
    
    with col2:
        # Traffic signal pie chart
        if len(signals_data) > 0:
            # Calculate averages
            avg_cycle = signals_df["Cycle Time (sec)"].mean()
            avg_green = signals_df["Green Time (sec)"].mean()
            avg_red = signals_df["Red Time (sec)"].mean()
            
            # Create a pie chart for average signal times
            fig = go.Figure(data=[go.Pie(
                labels=['Green', 'Red'],
                values=[avg_green, avg_red],
                hole=.3,
                marker_colors=['green', 'red']
            )])
            
            fig.update_layout(
                title_text=f"Average Signal Time Distribution",
                height=300
            )
            
            st.plotly_chart(fig, use_container_width=True)
            
            # Display average calculations
            st.write(f"**Average cycle time:** {avg_cycle:.1f} seconds")
            st.write(f"**Average green time:** {avg_green:.1f} seconds ({avg_green/avg_cycle*100:.1f}%)")
            st.write(f"**Average red time:** {avg_red:.1f} seconds ({avg_red/avg_cycle*100:.1f}%)")

elif tab_selection == "Bus Schedule":
    st.header("Bus Schedule Information")
    
    # Get bus schedule data
    schedule = st.session_state.transport_system.bus_schedule
    
    if schedule:
        # Convert schedule to a DataFrame
        schedule_data = []
        for route, data in schedule.items():
            route_str = " → ".join(route)
            schedule_data.append({
                "Route": route_str,
                "Buses Allocated": data['buses'],
                "Frequency": data['frequency'],
                "Stops": len(data['stops'])
            })
        
        schedule_df = pd.DataFrame(schedule_data)
        
        # Display the schedule
        st.subheader("Bus Route Schedule")
        st.dataframe(schedule_df, hide_index=True, use_container_width=True)
        
        # Create a bar chart for bus allocation
        fig = px.bar(
            schedule_df,
            x="Route",
            y="Buses Allocated",
            color="Frequency",
            title="Bus Allocation by Route",
            height=400
        )
        
        st.plotly_chart(fig, use_container_width=True)
        
        # Select a route to visualize
        st.subheader("Route Visualization")
        
        # Convert tuple keys to strings for selectbox
        route_options = [" → ".join(route) for route in schedule.keys()]
        selected_route_str = st.selectbox("Select a route to visualize:", route_options)
        
        if selected_route_str:
            # Find the corresponding tuple in the original schedule
            selected_route = None
            for route in schedule.keys():
                if " → ".join(route) == selected_route_str:
                    selected_route = route
                    break
            
            if selected_route:
                # Get route data
                route_data = schedule[selected_route]
                stops = route_data['stops']
                
                # Create a map
                if stops:
                    # Create map
                    route_map = st.session_state.transport_system.create_folium_map()
                    
                    # Add route
                    route_path = []
                    for i in range(len(stops)-1):
                        try:
                            path, _ = st.session_state.transport_system.dijkstra_shortest_path(stops[i], stops[i+1])
                            route_path.extend(path if i == 0 else path[1:])
                        except:
                            st.warning(f"Could not find path between {stops[i]} and {stops[i+1]}")
                    
                    if route_path:
                        route_map = st.session_state.transport_system.visualize_path_on_map(
                            route_map, 
                            route_path,
                            color='#FF8C00'  # Orange for bus routes
                        )
                        
                        # Add bus stop markers
                        for stop in stops:
                            pos = st.session_state.transport_system.G.nodes[stop]['pos']
                            folium.Marker(
                                [pos[0], pos[1]],
                                popup=f"Bus Stop: {stop}",
                                tooltip=f"Stop: {stop}",
                                icon=folium.Icon(color='blue', icon='bus', prefix='fa')
                            ).add_to(route_map)
                        
                        folium_static(route_map, width=700, height=500)
                        
                        # Display route details
                        col1, col2 = st.columns(2)
                        with col1:
                            st.write(f"**Route:** {' → '.join(stops)}")
                            st.write(f"**Number of stops:** {len(stops)}")
                            st.write(f"**Buses allocated:** {route_data['buses']}")
                            st.write(f"**Service frequency:** {route_data['frequency']}")
                        
                        with col2:
                            # Calculate total distance
                            total_distance = 0
                            for i in range(len(route_path)-1):
                                u = route_path[i]
                                v = route_path[i+1]
                                if st.session_state.transport_system.G.has_edge(u, v):
                                    total_distance += st.session_state.transport_system.G[u][v]['distance']
                            
                            # Estimate total travel time (30 km/h average speed for buses plus 30 seconds per stop)
                            bus_speed = 30  # km/h
                            time_minutes = (total_distance / bus_speed * 60) + (len(stops) * 0.5)
                            
                            st.write(f"**Total route distance:** {total_distance:.2f} km")
                            st.write(f"**Estimated travel time:** {time_minutes:.1f} minutes")
                            st.write(f"**Average speed:** 30 km/h (including stops)")
                    else:
                        st.error("Could not visualize the route path")
                else:
                    st.error("No stops found for this route")
    else:
        st.warning("No bus schedule data available")

elif tab_selection == "Emergency Services":
    st.header("Emergency Services")
    
    col1, col2 = st.columns([3, 1])
    
    with col2:
        st.subheader("Hospital Information")
        
        hospitals = list(st.session_state.transport_system.hospitals.keys())
        for hospital in hospitals:
            st.write(f"🏥 **{hospital}**")
            
            # Calculate average distance to this hospital from all locations
            distances = []
            for node in st.session_state.transport_system.G.nodes():
                if node != hospital:
                    try:
                        _, length = st.session_state.transport_system.dijkstra_shortest_path(node, hospital)
                        distances.append(length)
                    except:
                        pass
            
            if distances:
                avg_distance = sum(distances) / len(distances)
                st.write(f"   Avg. distance: {avg_distance:.2f} km")
                st.write(f"   Avg. emergency time: {avg_distance/60*60:.1f} min")  # Assuming 60 km/h for emergency vehicles
        
        st.divider()
        
        if st.session_state.emergency_mode:
            st.warning("⚠️ Emergency Mode Active")
            st.write("Emergency vehicles get priority at traffic signals and can use optimized routes.")
        else:
            st.info("🔔 Enable Emergency Mode in the sidebar to activate priority routing")
    
    with col1:
        st.subheader("Emergency Route Map")
        
        # Create map
        emergency_map = st.session_state.transport_system.create_folium_map()
        
        # Add current path to map if in emergency mode and a path exists
        if st.session_state.emergency_mode and st.session_state.current_path:
            emergency_map = st.session_state.transport_system.visualize_path_on_map(
                emergency_map, 
                st.session_state.current_path,
                color='red'  # Red for emergency routes
            )
            
            # Display the map
            folium_static(emergency_map, width=700, height=500)
            
            # Route details
            st.subheader("Emergency Route Details")
            
            # Calculate metrics
            route_length = 0
            for i in range(len(st.session_state.current_path)-1):
                u = st.session_state.current_path[i]
                v = st.session_state.current_path[i+1]
                if st.session_state.transport_system.G.has_edge(u, v):
                    route_length += st.session_state.transport_system.G[u][v]['weight']
            
            emergency_speed = 60  # km/h for emergency vehicles
            estimated_time = route_length / emergency_speed * 60  # minutes
            
            wait_time = sum(st.session_state.wait_times.values()) / 60  # minutes
            
            st.write(f"**Total distance:** {route_length:.2f} km")
            st.write(f"**Estimated travel time:** {estimated_time:.1f} minutes")
            st.write(f"**Reduced traffic light wait time:** {wait_time:.1f} minutes (80% reduction applied)")
            st.write(f"**Total emergency response time:** {estimated_time + wait_time:.1f} minutes")
            
            # Show wait times at traffic signals
            if st.session_state.wait_times:
                st.subheader("Traffic Signal Wait Times")
                
                wait_data = []
                for node, wait in st.session_state.wait_times.items():
                    if wait > 0:
                        wait_data.append({"Intersection": node, "Wait Time (sec)": wait})
                
                if wait_data:
                    wait_df = pd.DataFrame(wait_data)
                    st.dataframe(wait_df, hide_index=True, use_container_width=True)
                else:
                    st.info("No significant wait times at traffic signals")
        else:
            # Just show the map with hospitals
            folium_static(emergency_map, width=700, height=500)
            
            if not st.session_state.emergency_mode:
                st.info("Enable Emergency Mode in the sidebar to calculate priority routes")
            elif not st.session_state.current_path:
                st.info("Select locations and calculate a route to see emergency routing")

# Footer
st.divider()
st.caption("Cairo Transport System - Developed with Streamlit and NetworkX")

//app.py