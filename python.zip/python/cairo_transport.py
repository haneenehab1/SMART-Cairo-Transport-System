import networkx as nx
import heapq
import random
import folium
from datetime import datetime, timedelta
import math
from collections import defaultdict

class CairoTransportSystem:
    def __init__(self):
        # Initialize the transport network graph
        self.G = nx.Graph()
        self.emergency_mode = False
        self.hospitals = {}
        self.current_path = None
        self.current_mst = None
        self.traffic_signals = {}  # Stores traffic signal timing data
        self.resource_allocation = {}  # For dynamic programming resource allocation
        self.bus_schedule = {}  # For bus scheduling
        self.current_wait_times = {}  # To store wait times for current path

        # Create sample data for Cairo
        self.create_sample_data()
        
        # Initialize traffic signals and schedules
        self.initialize_traffic_signals()
        self.initialize_bus_schedule()
    
    def create_sample_data(self):
        """Create sample data for Cairo's transport network"""
        # Major locations in Cairo
        locations = {
            "Downtown": (30.0444, 31.2357),
            "Giza": (30.0131, 31.2089),
            "Heliopolis": (30.0972, 31.3214),
            "Maadi": (29.9627, 31.2597),
            "Nasr City": (30.0500, 31.3667),
            "6th October City": (29.9668, 30.9333),
            "Shubra": (30.1286, 31.2422),
            "Zamalek": (30.0638, 31.2175),
            "Mohandessin": (30.0561, 31.2004),
            "Ain Shams": (30.1317, 31.3075),
            "Cairo University": (30.0276, 31.2101),
            "Cairo Airport": (30.1219, 31.4056),
            "Al-Azhar University": (30.0451, 31.2625),
            "Egyptian Museum": (30.0478, 31.2336),
            "Khan el-Khalili": (30.0479, 31.2616)
        }
        
        # Add nodes (locations) to the graph
        for name, coords in locations.items():
            self.G.add_node(name, pos=coords, population=random.randint(1000, 100000))
            
        # Add edges (roads) with random weights representing distance and traffic
        all_nodes = list(self.G.nodes())
        for i in range(len(all_nodes)):
            for j in range(i+1, len(all_nodes)):
                if random.random() < 0.4:  # 40% chance of connection
                    node1 = all_nodes[i]
                    node2 = all_nodes[j]
                    pos1 = self.G.nodes[node1]['pos']
                    pos2 = self.G.nodes[node2]['pos']
                    # Calculate approximate distance
                    distance = ((pos1[0]-pos2[0])**2 + (pos1[1]-pos2[1])**2)**0.5 * 111  # km
                    # Add traffic factor (1-3)
                    traffic_factor = 1 + random.random() * 2
                    weight = distance * traffic_factor
                    self.G.add_edge(node1, node2, weight=weight, distance=distance, traffic=traffic_factor)
        
        # Define hospitals (some locations will serve as hospitals)
        hospital_names = ["Cairo University", "Ain Shams", "6th October City", "Heliopolis", "Nasr City"]
        self.hospitals = {name: self.G.nodes[name]['pos'] for name in hospital_names if name in self.G.nodes}
    
    def initialize_traffic_signals(self):
        """Initialize traffic signal timing data for intersections"""
        # For simplicity, we'll consider nodes with degree >= 3 as intersections
        for node in self.G.nodes():
            if self.G.degree(node) >= 3:
                # Random cycle time between 60-120 seconds
                cycle_time = random.randint(60, 120)
                # Random green time between 20-40 seconds
                green_time = random.randint(20, 40)
                self.traffic_signals[node] = {
                    'cycle_time': cycle_time,
                    'green_time': green_time,
                    'red_time': cycle_time - green_time,
                    'last_switch': datetime.now()
                }
                
    def initialize_bus_schedule(self):
        """Initialize bus schedule using dynamic programming approach"""
        # Key bus routes in Cairo
        bus_routes = [
            ["Downtown", "Giza", "Cairo University", "Mohandessin"],
            ["Heliopolis", "Nasr City", "Downtown", "Maadi"],
            ["Shubra", "Downtown", "6th October City"],
            ["Zamalek", "Downtown", "Cairo Airport"]
        ]
        
        # Use dynamic programming to optimize bus frequencies
        max_buses = 10  # Total available buses
        route_demands = [random.randint(5, 20) for _ in bus_routes]  # Random demand for each route
        
        # DP table: dp[i][j] = optimal allocation for first i routes with j buses
        dp = [[float('inf')] * (max_buses + 1) for _ in range(len(bus_routes) + 1)]
        dp[0][0] = 0
        
        # Backtracking table
        backtrack = [[0] * (max_buses + 1) for _ in range(len(bus_routes) + 1)]
        
        for i in range(1, len(bus_routes) + 1):
            for j in range(max_buses + 1):
                min_cost = float('inf')
                best_k = 0
                max_possible = min(j, 5)  # No more than 5 buses per route
                
                for k in range(0, max_possible + 1):
                    cost = dp[i-1][j-k] + (route_demands[i-1] / (k if k > 0 else 1))
                    
                    if cost < min_cost:
                        min_cost = cost
                        best_k = k
                
                dp[i][j] = min_cost
                backtrack[i][j] = best_k
        
        # Find optimal allocation
        remaining_buses = max_buses
        self.bus_schedule = {}
        
        for i in range(len(bus_routes), 0, -1):
            buses = backtrack[i][remaining_buses]
            route = bus_routes[i-1]
            self.bus_schedule[tuple(route)] = {
                'buses': buses,
                'frequency': f"Every {60//buses} minutes" if buses > 0 else "No service",
                'stops': route
            }
            remaining_buses -= buses
            
    def kruskal_mst(self):
        """Implement Kruskal's algorithm for MST"""
        mst = nx.minimum_spanning_tree(self.G, algorithm='kruskal', weight='weight')
        return mst
        
    def dijkstra_shortest_path(self, start, end):
        """Dijkstra's algorithm for shortest path"""
        try:
            path = nx.dijkstra_path(self.G, start, end, weight='weight')
            length = nx.dijkstra_path_length(self.G, start, end, weight='weight')
            return path, length
        except nx.NetworkXNoPath:
            raise nx.NetworkXNoPath(f"No path exists between {start} and {end}")
        
    def a_star_shortest_path(self, start, end):
        """A* algorithm for emergency vehicles with traffic signal optimization"""
        def heuristic(u, v):
            # Simple heuristic - Euclidean distance
            pos_u = self.G.nodes[u]['pos']
            pos_v = self.G.nodes[v]['pos']
            return ((pos_u[0]-pos_v[0])**2 + (pos_u[1]-pos_v[1])**2)**0.5 * 111
            
        # We'll modify the weight calculation to account for traffic signals
        def weight(u, v, d):
            base_weight = d['weight']
            
            # If this is an emergency vehicle and we're at an intersection
            if self.emergency_mode and v in self.traffic_signals:
                signal = self.traffic_signals[v]
                current_time = datetime.now()
                time_since_switch = (current_time - signal['last_switch']).total_seconds() % signal['cycle_time']
                
                # If light is red, estimate wait time (reduce weight for emergency)
                if time_since_switch > signal['green_time']:
                    remaining_red = signal['cycle_time'] - time_since_switch
                    # Emergency vehicles can pass through with minimal delay
                    return base_weight + remaining_red * 0.1
                
            return base_weight
            
        try:
            path = nx.astar_path(self.G, start, end, heuristic=heuristic, weight=weight)
            length = nx.astar_path_length(self.G, start, end, heuristic=heuristic, weight=weight)
            return path, length
        except nx.NetworkXNoPath:
            raise nx.NetworkXNoPath(f"No path exists between {start} and {end}")
        
    def time_dependent_shortest_path(self, start, end, time):
        """Modified Dijkstra's for time-varying traffic"""
        # Simple model where traffic increases during rush hours
        hour = time.hour
        if 7 <= hour <= 9 or 16 <= hour <= 19:  # Rush hours
            traffic_factor = 1.5
        else:
            traffic_factor = 1.0
            
        # Create temporary graph with adjusted weights
        tempG = self.G.copy()
        for u, v, data in tempG.edges(data=True):
            data['temp_weight'] = data['weight'] * traffic_factor
            
        try:
            path = nx.dijkstra_path(tempG, start, end, weight='temp_weight')
            length = nx.dijkstra_path_length(tempG, start, end, weight='temp_weight')
            return path, length
        except nx.NetworkXNoPath:
            raise nx.NetworkXNoPath(f"No path exists between {start} and {end}")
        
    def calculate_traffic_wait_times(self, path, current_time):
        """Calculate estimated wait times at traffic signals along a path"""
        wait_times = {}
        
        for node in path:
            if node in self.traffic_signals:
                signal = self.traffic_signals[node]
                time_since_switch = (current_time - signal['last_switch']).total_seconds() % signal['cycle_time']
                
                if time_since_switch > signal['green_time']:
                    remaining_red = signal['cycle_time'] - time_since_switch
                    wait_times[node] = remaining_red * (0.2 if self.emergency_mode else 1.0)  # 80% reduction for emergency
                else:
                    wait_times[node] = 0
                    
        return wait_times
        
    def optimize_emergency_route(self, path, wait_times):
        """Optimize route for emergency vehicles by minimizing wait times"""
        optimized_path = path.copy()
        optimized_wait = sum(wait_times.values())
        
        # Try to find alternative paths with less wait time
        start = path[0]
        end = path[-1]
        
        # Get top 3 shortest paths
        try:
            all_paths = list(nx.shortest_simple_paths(self.G, start, end, weight='weight'))
            for alt_path in all_paths[:3]:
                alt_wait_times = self.calculate_traffic_wait_times(alt_path, datetime.now())
                alt_total_wait = sum(alt_wait_times.values())
                
                if alt_total_wait < optimized_wait:
                    optimized_path = alt_path
                    optimized_wait = alt_total_wait
                    wait_times = alt_wait_times
        except:
            pass
            
        return optimized_path, wait_times
        
    def get_time_analysis_data(self, start, end):
        """Get time analysis data for different times of day"""
        if not start or not end or start not in self.G.nodes or end not in self.G.nodes:
            raise ValueError("Please select valid start and destination locations")
            
        # Define time periods to analyze
        time_periods = [
            ("Early Morning (4-6)", datetime.now().replace(hour=5, minute=0)),
            ("Morning (7-9)", datetime.now().replace(hour=8, minute=0)),
            ("Late Morning (10-12)", datetime.now().replace(hour=11, minute=0)),
            ("Afternoon (13-15)", datetime.now().replace(hour=14, minute=0)),
            ("Evening (16-18)", datetime.now().replace(hour=17, minute=0)),
            ("Late Evening (19-21)", datetime.now().replace(hour=20, minute=0)),
            ("Night (22-3)", datetime.now().replace(hour=23, minute=0))
        ]
        
        # Calculate travel times for each period
        times = []
        labels = []
        for label, time in time_periods:
            try:
                _, length = self.time_dependent_shortest_path(start, end, time)
                times.append(length)
                labels.append(label)
            except:
                continue
                
        return labels, times
        
    def create_folium_map(self, center=None):
        """Create a folium map for visualization"""
        if center is None:
            # Default center (Cairo)
            center = [30.0444, 31.2357]
        
        # Create map
        m = folium.Map(location=center, zoom_start=12, tiles="OpenStreetMap")
        
        # Add nodes
        for node, data in self.G.nodes(data=True):
            pos = data['pos']
            color = 'blue'
            # Highlight hospitals
            if node in self.hospitals:
                folium.Marker(
                    [pos[0], pos[1]],
                    popup=f"Hospital: {node}",
                    tooltip=node,
                    icon=folium.Icon(color='red', icon='plus', prefix='fa')
                ).add_to(m)
            # Add other locations
            else:
                folium.Marker(
                    [pos[0], pos[1]],
                    popup=f"Location: {node}",
                    tooltip=node,
                    icon=folium.Icon(color=color, icon='info', prefix='fa')
                ).add_to(m)
            
        # Add edges (roads)
        for u, v, data in self.G.edges(data=True):
            pos_u = self.G.nodes[u]['pos']
            pos_v = self.G.nodes[v]['pos']
            
            weight = data.get('weight', 1.0)
            # Normalize weight for line width (thicker = more traffic)
            norm_weight = 2 + min(4, weight / 5)
            
            folium.PolyLine(
                [(pos_u[0], pos_u[1]), (pos_v[0], pos_v[1])],
                color='gray',
                weight=norm_weight,
                opacity=0.7,
                tooltip=f"{u} to {v}: {data.get('distance', 0):.2f} km"
            ).add_to(m)
            
        return m
        
    def visualize_path_on_map(self, m, path, color='blue'):
        """Add a path to a folium map"""
        if not path:
            return m
            
        # Get coordinates for the path
        path_coords = []
        for node in path:
            pos = self.G.nodes[node]['pos']
            path_coords.append((pos[0], pos[1]))
            
        # Add path line
        folium.PolyLine(
            path_coords,
            color=color,
            weight=5,
            opacity=0.8,
            tooltip="Route"
        ).add_to(m)
        
        # Add markers for start and end
        start_pos = self.G.nodes[path[0]]['pos']
        end_pos = self.G.nodes[path[-1]]['pos']
        
        folium.Marker(
            [start_pos[0], start_pos[1]],
            popup=f"Start: {path[0]}",
            tooltip="Start",
            icon=folium.Icon(color='green', icon='play', prefix='fa')
        ).add_to(m)
        
        folium.Marker(
            [end_pos[0], end_pos[1]],
            popup=f"End: {path[-1]}",
            tooltip="End",
            icon=folium.Icon(color='red', icon='stop', prefix='fa')
        ).add_to(m)
        
        return m
        
    def visualize_mst_on_map(self, m, mst, color='red'):
        """Add a minimum spanning tree to a folium map"""
        if not mst:
            return m
            
        # Add MST edges
        for u, v, data in mst.edges(data=True):
            pos_u = self.G.nodes[u]['pos']
            pos_v = self.G.nodes[v]['pos']
            
            folium.PolyLine(
                [(pos_u[0], pos_u[1]), (pos_v[0], pos_v[1])],
                color=color,
                weight=3,
                opacity=0.8,
                tooltip=f"{u} to {v}: {data.get('weight', 0):.2f}"
            ).add_to(m)
            
        return m